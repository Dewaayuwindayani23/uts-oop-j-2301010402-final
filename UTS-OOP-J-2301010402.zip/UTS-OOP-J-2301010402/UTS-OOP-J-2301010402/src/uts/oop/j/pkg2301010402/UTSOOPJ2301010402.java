package uts.oop.j.pkg2301010402;

import java.util.Scanner;

public class UTSOOPJ2301010402 {
    static Note[] notes = new Note[100];
    static int count = 0;
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int pilihan;
        do {
            System.out.println("\n--- Menu Aplikasi KUE ---");
            System.out.println("1. Tambah Nama kue");
            System.out.println("2. Tampilkan data kue");
            System.out.println("3. Ubah data kue");
            System.out.println("4. Hapus data kue");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = scanner.nextInt();
            scanner.nextLine();

            switch (pilihan) {
                case 1: tambahCatatan(); break;
                case 2: tampilkanCatatan(); break;
                case 3: ubahCatatan(); break;
                case 4: hapusCatatan(); break;
                case 5: System.out.println("Terima kasih!"); break;
                default: System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 5);
    }

    static void tambahCatatan() {
        if (count >= notes.length) {
            System.out.println("Penyimpanan penuh!");
            return;
        }
        System.out.print("Masukkan ID Kue: ");
        int id = scanner.nextInt(); scanner.nextLine();
        System.out.print("Masukkan isi Data kue: ");
        String isi = scanner.nextLine();
        notes[count++] = new Note(id, isi);
        System.out.println("Catatan ditambahkan!");
    }

    static void tampilkanCatatan() {
        if (count == 0) {
            System.out.println("Tidak ada catatan.");
            return;
        }
        for (int i = 0; i < count; i++) {
            System.out.println(notes[i]);
        }
    }

    static void ubahCatatan() {
        System.out.print("Masukkan ID Kue yang ingin diubah: ");
        int id = scanner.nextInt(); scanner.nextLine();
        for (int i = 0; i < count; i++) {
            if (notes[i].getId() == id) {
                System.out.print("Isi baru: ");
                String baru = scanner.nextLine();
                notes[i].setContent(baru);
                System.out.println("Catatan berhasil diubah.");
                return;
            }
        }
        System.out.println("Catatan tidak ditemukan.");
    }

    static void hapusCatatan() {
        System.out.print("Masukkan ID Kue yang ingin dihapus: ");
        int id = scanner.nextInt(); scanner.nextLine();
        for (int i = 0; i < count; i++) {
            if (notes[i].getId() == id) {
                for (int j = i; j < count - 1; j++) {
                    notes[j] = notes[j + 1];
                }
                notes[--count] = null;
                System.out.println("Catatan berhasil dihapus.");
                return;
            }
        }
        System.out.println("Catatan tidak ditemukan.");
    }
}
